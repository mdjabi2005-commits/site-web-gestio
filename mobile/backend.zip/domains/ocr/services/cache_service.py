"""
Vendor Cache Service - Optimisation pour éviter les appels API redondants à Groq
Table: vendor_cache (marchand -> catégorie)
"""

import logging
from typing import Optional
from datetime import datetime

from shared.database import get_db_connection, close_connection

logger = logging.getLogger(__name__)


async def init_vendor_cache() -> bool:
    """
    Crée la table vendor_cache si elle n'existe pas.
    """
    conn = None
    try:
        conn = get_db_connection()
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS vendor_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_name TEXT UNIQUE NOT NULL,
                categorie TEXT NOT NULL,
                sous_categorie TEXT,
                last_updated TEXT NOT NULL
            )
        """)
        conn.commit()
        logger.info("vendor_cache table initialized")
        return True
    except Exception as e:
        logger.error(f"Error initializing vendor_cache: {e}")
        return False
    finally:
        close_connection(conn)


async def get_category(merchant_name: str) -> Optional[dict]:
    """
    Récupère la catégorie associée à un marchand.

    Returns:
        dict {categorie, sous_categorie} ou None si absent
    """
    if not merchant_name:
        return None

    conn = None
    try:
        conn = get_db_connection()
        result = await conn.fetch_one(
            "SELECT categorie, sous_categorie FROM vendor_cache WHERE merchant_name = ?",
            (merchant_name.strip(),),
        )
        if result:
            return {
                "categorie": result["categorie"],
                "sous_categorie": result["sous_categorie"],
            }
        return None
    except Exception as e:
        logger.error(f"Error getting vendor category: {e}")
        return None
    finally:
        close_connection(conn)


async def set_category(
    merchant_name: str, categorie: str, sous_categorie: Optional[str] = None
) -> bool:
    """
    Met en cache la catégorie d'un marchand.
    INSERT OR REPLACE pour mettre à jour si existant.
    """
    if not merchant_name or not categorie:
        return False

    conn = None
    try:
        conn = get_db_connection()
        await conn.execute(
            """
            INSERT OR REPLACE INTO vendor_cache (merchant_name, categorie, sous_categorie, last_updated)
            VALUES (?, ?, ?, ?)
        """,
            (
                merchant_name.strip(),
                categorie,
                sous_categorie,
                datetime.now().isoformat(),
            ),
        )
        conn.commit()
        logger.info(f"Cached vendor: {merchant_name} -> {categorie}/{sous_categorie}")
        return True
    except Exception as e:
        logger.error(f"Error setting vendor category: {e}")
        return False
    finally:
        close_connection(conn)


vendor_cache_service = {
    "init": init_vendor_cache,
    "get": get_category,
    "set": set_category,
}
