# Backend API Package
# Re-export toutes les fonctions pour Pyodide
# BUILD_ID: 2026-03-21-FORCE-MIGRATION-V7-ROBUST

from .setup import initialize_backend
from .transactions import (
    add_transaction,
    update_transaction,
    delete_transaction,
    get_structured_categories,
)
from domains.ocr.api.ocr import scan_text, scan_document, process_pdf

from .attachments import (
    delete_attachment,
)

from .recurrences import (
    add_recurrence,
    update_recurrence,
    delete_recurrence,
    backfill_recurrences,
    refresh_echeances,
)

from .budgets import (
    get_budgets,
    get_budget,
    add_budget,
    update_budget,
    delete_budget,
    get_budgets_status_api,
    get_budgets_summary_api,
)

from .objectifs import (
    get_objectifs,
    add_objectif,
    update_objectif,
    delete_objectif,
    refresh_objectifs,
)

__all__ = [
    "initialize_backend",
    # Transactions
    "add_transaction",
    "update_transaction",
    "delete_transaction",
    "get_structured_categories",
    # Attachments
    "delete_attachment",
    # Recurrences
    "add_recurrence",
    "update_recurrence",
    "delete_recurrence",
    "backfill_recurrences",
    "refresh_echeances",
    "scan_text",
    "scan_document",
    "process_pdf",
    # Budgets
    "get_budgets",
    "get_budget",
    "add_budget",
    "update_budget",
    "delete_budget",
    "get_budgets_status_api",
    "get_budgets_summary_api",
    # Objectifs
    "get_objectifs",
    "add_objectif",
    "update_objectif",
    "delete_objectif",
    "refresh_objectifs",
]
