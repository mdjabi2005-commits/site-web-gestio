"""
Initialisation du backend et de la base de données.
"""

import logging
import asyncio
import time

logger = logging.getLogger(__name__)


async def initialize_backend():
    """
    Initialise toutes les tables et index de la base de données.
    Appelé au démarrage par le frontend.
    """
    start_total = time.time()
    from shared.database import get_db_connection, close_connection

    conn = get_db_connection()
    try:
        logger.info("🎬 Initialisation du backend (Schema SQL)...")

        queries = [
            """CREATE TABLE IF NOT EXISTS vendor_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_name TEXT UNIQUE NOT NULL,
                categorie TEXT NOT NULL,
                sous_categorie TEXT,
                last_updated TEXT NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TEXT
            )""",
            """CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                categorie TEXT NOT NULL,
                sous_categorie TEXT,
                description TEXT,
                montant REAL NOT NULL,
                date TEXT NOT NULL,
                source TEXT DEFAULT 'Manuel',
                recurrence TEXT DEFAULT 'Aucune',
                date_fin TEXT DEFAULT '',
                compte_id INTEGER,
                external_id TEXT UNIQUE
            )""",
            """CREATE TABLE IF NOT EXISTS transaction_attachments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_id INTEGER NOT NULL,
                file_path TEXT NOT NULL,
                file_name TEXT NOT NULL,
                file_type TEXT,
                upload_date TEXT NOT NULL,
                size INTEGER,
                FOREIGN KEY (transaction_id) REFERENCES transactions (id) ON DELETE CASCADE
            )""",
            "CREATE INDEX IF NOT EXISTS idx_attachments_tx_id ON transaction_attachments(transaction_id)",
            """CREATE TABLE IF NOT EXISTS recurrences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_id INTEGER,
                frequence TEXT NOT NULL,
                intervalle INTEGER DEFAULT 1,
                prochaine_occurrence TEXT,
                actif INTEGER DEFAULT 1,
                FOREIGN KEY (transaction_id) REFERENCES transactions (id) ON DELETE CASCADE
            )""",
            "CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date DESC)",
            "CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type)",
            "CREATE INDEX IF NOT EXISTS idx_transactions_categorie ON transactions(categorie)",
            """CREATE TABLE IF NOT EXISTS budgets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                categorie TEXT NOT NULL,
                montant_limite REAL NOT NULL,
                periode TEXT NOT NULL DEFAULT 'Mensuel',
                date_debut TEXT NOT NULL,
                date_fin TEXT,
                alert_seuil REAL DEFAULT 80.0,
                actif INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""",
            "CREATE INDEX IF NOT EXISTS idx_budgets_categorie ON budgets(categorie)",
            """CREATE TABLE IF NOT EXISTS objectifs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom TEXT NOT NULL,
                montant_cible REAL NOT NULL,
                icone TEXT,
                couleur TEXT,
                date_limite TEXT,
                progression_actuelle REAL DEFAULT 0.0,
                statut TEXT DEFAULT 'En cours',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                derniere_modification TEXT
            )""",
            "CREATE INDEX IF NOT EXISTS idx_objectifs_statut ON objectifs(statut)",
        ]

        for query in queries:
            logger.debug(f"Executing: {query[:50]}...")
            await conn.execute(query)

        # ─── MIGRATIONS SCHÉMA ─────────────────────────────────────────────────
        # Ces migrations corrigent les vieux schémas sur les appareils existants.
        # Elles s'exécutent à chaque démarrage mais sont idempotentes.

        async def migrate_vendor_cache():
            try:
                await conn.fetch_one(
                    "SELECT merchant_name, last_updated FROM vendor_cache LIMIT 1"
                )
            except Exception as e:
                if "no such column" in str(e).lower():
                    logger.warning("Migration vendor_cache → nouveau schéma")
                    await conn.execute("DROP TABLE IF EXISTS vendor_cache")
                    await conn.execute("""CREATE TABLE vendor_cache (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        merchant_name TEXT UNIQUE NOT NULL,
                        categorie TEXT NOT NULL,
                        sous_categorie TEXT,
                        last_updated TEXT NOT NULL
                    )""")

        async def migrate_transactions():
            try:
                await conn.fetch_one(
                    "SELECT compte_id, external_id FROM transactions LIMIT 1"
                )
                # Vérifier qu'il n'y a pas compte_iban (si ça passe c'est qu'il y est, on doit migrer)
                try:
                    await conn.fetch_one("SELECT compte_iban FROM transactions LIMIT 1")
                    needs_migration = True  # L'ancienne colonne est encore là!
                except Exception:
                    needs_migration = False  # Parfait, elle n'y est pas
            except Exception as e:
                if "no such column" in str(e).lower():
                    needs_migration = True
                else:
                    needs_migration = False

            if needs_migration:
                logger.warning(
                    "Migration transactions → nouveau schéma (preservation des données)"
                )
                try:
                    # Tenter de récupérer toutes les données possibles sans préciser les colonnes pour voir ce qui existe
                    # En SQLite "SELECT * FROM transactions" ramènera des dicts avec les clés disponibles
                    rows = await conn.fetch_all("SELECT * FROM transactions")
                    await conn.execute("DROP TABLE transactions")
                    await conn.execute("""CREATE TABLE transactions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        type TEXT NOT NULL,
                        categorie TEXT NOT NULL,
                        sous_categorie TEXT,
                        description TEXT,
                        montant REAL NOT NULL,
                        date TEXT NOT NULL,
                        source TEXT DEFAULT 'Manuel',
                        recurrence TEXT DEFAULT 'Aucune',
                        date_fin TEXT DEFAULT '',
                        compte_id INTEGER,
                        external_id TEXT UNIQUE
                    )""")
                    for row in rows:
                        try:
                            # Mapping intelligent
                            compte_id = row.get("compte_id")
                            if compte_id is None and "compte_iban" in row:
                                compte_id = None  # On perd le mapping IBAN

                            await conn.execute(
                                "INSERT OR IGNORE INTO transactions (id,type,categorie,sous_categorie,description,montant,date,source,recurrence,date_fin,compte_id,external_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                                (
                                    row.get("id"),
                                    row.get("type", "Dépense"),
                                    row.get("categorie", "Divers"),
                                    row.get("sous_categorie", ""),
                                    row.get("description", ""),
                                    row.get("montant", 0.0),
                                    row.get("date", ""),
                                    row.get("source", "Manuel"),
                                    row.get("recurrence", "Aucune"),
                                    row.get("date_fin", ""),
                                    compte_id,
                                    row.get("external_id"),
                                ),
                            )
                        except Exception as e:
                            logger.error(f"Erreur re-insertion transaction: {e}")
                    logger.info(f"✅ Transactions migrées")
                except Exception as e:
                    logger.warning(f"Migration transactions failed: {e}")

        async def migrate_recurrences():
            try:
                await conn.fetch_one(
                    "SELECT transaction_id, intervalle FROM recurrences LIMIT 1"
                )
            except Exception as e:
                if "no such column" in str(e).lower():
                    logger.warning(
                        "Migration recurrences → nouveau schéma (données perdues)"
                    )
                    await conn.execute("DROP TABLE IF EXISTS recurrences")
                    await conn.execute("""CREATE TABLE recurrences (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        transaction_id INTEGER,
                        frequence TEXT NOT NULL,
                        intervalle INTEGER DEFAULT 1,
                        prochaine_occurrence TEXT,
                        actif INTEGER DEFAULT 1,
                        FOREIGN KEY (transaction_id) REFERENCES transactions (id) ON DELETE CASCADE
                    )""")

        async def migrate_app_settings():
            try:
                await conn.fetch_one("SELECT updated_at FROM app_settings LIMIT 1")
            except Exception as e:
                if "no such column" in str(e).lower():
                    try:
                        await conn.execute(
                            "ALTER TABLE app_settings ADD COLUMN updated_at TEXT"
                        )
                        logger.info("✅ app_settings: colonne updated_at ajoutée")
                    except Exception as alt_err:
                        logger.warning(f"Impossible d'ajouter updated_at: {alt_err}")

        async def migrate_budgets():
            try:
                # On assume le format standard : liste de dictionnaires
                cols_result = await conn.fetch_all("PRAGMA table_info(budgets)")
                existing_cols = [row["name"] for row in cols_result]
                logger.info(f"🔍 [Migration] Budgets: {existing_cols}")

                # 1. Renommage
                if (
                    "budget_mensuel" in existing_cols
                    and "montant_limite" not in existing_cols
                ):
                    logger.warning("🔄 Renommage budget_mensuel -> montant_limite")
                    await conn.execute(
                        "ALTER TABLE budgets RENAME COLUMN budget_mensuel TO montant_limite"
                    )
                if (
                    "date_creation" in existing_cols
                    and "created_at" not in existing_cols
                ):
                    await conn.execute(
                        "ALTER TABLE budgets RENAME COLUMN date_creation TO created_at"
                    )

                # 2. Additions
                cols_v2 = await conn.fetch_all("PRAGMA table_info(budgets)")
                names_after = [row["name"] for row in cols_v2]
                if "actif" not in names_after:
                    await conn.execute(
                        "ALTER TABLE budgets ADD COLUMN actif INTEGER DEFAULT 1"
                    )

                if not any(
                    c in names_after for c in ["montant_limite", "budget_mensuel"]
                ):
                    logger.warning("⚠️ Table budgets incomplète. Re-création.")
                    await conn.execute("DROP TABLE IF EXISTS budgets")
                    await conn.execute("""CREATE TABLE budgets (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        categorie TEXT NOT NULL,
                        montant_limite REAL NOT NULL,
                        periode TEXT NOT NULL DEFAULT 'Mensuel',
                        date_debut TEXT NOT NULL,
                        date_fin TEXT,
                        alert_seuil REAL DEFAULT 80.0,
                        actif INTEGER DEFAULT 1,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    )""")
            except Exception as e:
                logger.error(f"Erreur migrate_budgets: {e}")

        async def migrate_objectifs():
            try:
                cols_result = await conn.fetch_all("PRAGMA table_info(objectifs)")
                existing_cols = [row["name"] for row in cols_result]
                logger.info(f"🔍 [Migration] Objectifs: {existing_cols}")

                if not existing_cols:
                    logger.info(
                        "✅ objectifs: table n'existe pas encore, CREATE TABLE s'en occupera"
                    )
                    return

                required_cols = [
                    "nom",
                    "montant_cible",
                    "progression_actuelle",
                    "statut",
                    "created_at",
                ]
                missing_critical = [c for c in required_cols if c not in existing_cols]

                if len(missing_critical) >= 3:
                    logger.warning(
                        f"⚠️ Schéma objectifs gravement incomplet ({missing_critical}). "
                        "Recréation de la table avec préservation des données."
                    )
                    try:
                        rows = await conn.fetch_all("SELECT * FROM objectifs")
                        await conn.execute("DROP TABLE IF EXISTS objectifs")
                        await conn.execute("""CREATE TABLE IF NOT EXISTS objectifs (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            nom TEXT NOT NULL,
                            montant_cible REAL NOT NULL,
                            icone TEXT,
                            couleur TEXT,
                            date_limite TEXT,
                            progression_actuelle REAL DEFAULT 0.0,
                            statut TEXT DEFAULT 'En cours',
                            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                            derniere_modification TEXT
                        )""")
                        for row in rows:
                            try:
                                nom = row.get("nom") or row.get("titre") or "Sans Nom"
                                await conn.execute(
                                    """INSERT INTO objectifs
                                        (id, nom, montant_cible, icone, couleur, date_limite,
                                         progression_actuelle, statut, created_at, derniere_modification)
                                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                                    (
                                        row.get("id"),
                                        nom,
                                        row.get("montant_cible", 0.0),
                                        row.get("icone"),
                                        row.get("couleur"),
                                        row.get("date_limite"),
                                        row.get("progression_actuelle", 0.0),
                                        row.get("statut", "En cours"),
                                        row.get("created_at")
                                        or row.get("date_creation"),
                                        row.get("derniere_modification")
                                        or row.get("date_modification"),
                                    ),
                                )
                            except Exception as row_err:
                                logger.error(
                                    f"Erreur re-insertion objectif {row.get('id')}: {row_err}"
                                )
                        logger.info(
                            f"✅ objectifs: table recréée, {len(rows)} lignes préservées"
                        )
                    except Exception as recreate_err:
                        logger.error(
                            f"❌ Impossible de recréer la table objectifs: {recreate_err}"
                        )
                    finally:
                        return

                if "titre" in existing_cols and "nom" not in existing_cols:
                    logger.warning("🔄 Renommage titre -> nom")
                    await conn.execute(
                        "ALTER TABLE objectifs RENAME COLUMN titre TO nom"
                    )
                if (
                    "date_creation" in existing_cols
                    and "created_at" not in existing_cols
                ):
                    logger.warning("🔄 Renommage date_creation -> created_at")
                    await conn.execute(
                        "ALTER TABLE objectifs RENAME COLUMN date_creation TO created_at"
                    )
                if (
                    "date_modification" in existing_cols
                    and "derniere_modification" not in existing_cols
                ):
                    logger.warning(
                        "🔄 Renommage date_modification -> derniere_modification"
                    )
                    await conn.execute(
                        "ALTER TABLE objectifs RENAME COLUMN date_modification TO derniere_modification"
                    )

                cols_after_rename = await conn.fetch_all("PRAGMA table_info(objectifs)")
                names_after_rename = [row["name"] for row in cols_after_rename]

                cols_to_add = [
                    ("nom", "TEXT DEFAULT 'Sans Nom'"),
                    ("icone", "TEXT"),
                    ("couleur", "TEXT"),
                    ("montant_cible", "REAL DEFAULT 0.0"),
                    ("progression_actuelle", "REAL DEFAULT 0.0"),
                    ("statut", "TEXT DEFAULT 'En cours'"),
                    ("created_at", "TEXT"),
                    ("derniere_modification", "TEXT"),
                ]

                for col_name, col_def in cols_to_add:
                    if col_name not in names_after_rename:
                        try:
                            logger.info(f"➕ Ajout colonne {col_name}")
                            await conn.execute(
                                f"ALTER TABLE objectifs ADD COLUMN {col_name} {col_def}"
                            )
                            logger.info(f"✅ Colonne {col_name} ajoutée")
                        except Exception as add_err:
                            if (
                                "duplicate column" in str(add_err).lower()
                                or "already exists" in str(add_err).lower()
                            ):
                                logger.info(f"⚠️ Colonne {col_name} existe déjà")
                            else:
                                logger.warning(
                                    f"⚠️ Impossible d'ajouter {col_name}: {add_err}"
                                )

                cols_final = await conn.fetch_all("PRAGMA table_info(objectifs)")
                final_col_names = [row["name"] for row in cols_final]
                logger.info(
                    f"✅ objectifs: migration terminée. Colonnes: {final_col_names}"
                )

                missing_final = [c for c in required_cols if c not in final_col_names]
                if missing_final:
                    logger.error(
                        f"❌ Colonnes toujours manquantes après migration: {missing_final}"
                    )
                else:
                    logger.info("✅ Toutes les colonnes requises sont présentes")

            except Exception as e:
                logger.error(f"❌ Erreur migrate_objectifs: {e}")

        await migrate_vendor_cache()
        await migrate_transactions()
        await migrate_recurrences()
        await migrate_app_settings()
        await migrate_budgets()
        await migrate_objectifs()
        # ────────────────────────────────────────────────────────────────────────

        conn.commit()
        init_time = (time.time() - start_total) * 1000
        logger.info(f"✅ Backend prêt (Schéma DB initialisé en {init_time:.2f}ms)")
        return True
    except Exception as e:
        import traceback

        traceback.print_exc()
        logger.error(f"❌ Échec de l'initialisation du backend: {e}")
        return False
    finally:
        close_connection(conn)
