"""
API Layer pour Pyodide
Point d'entrée unique pour le frontend React (offline 100%)

Cet module expose des fonctions JSON-ready qui peuvent être appelées
depuis le frontend via Pyodide.runPython().
"""

# Re-export depuis le package api
from api import (
    initialize_backend,
    add_transaction,
    update_transaction,
    delete_transaction,
    get_structured_categories,
    delete_attachment,
    add_recurrence,
    update_recurrence,
    delete_recurrence,
    backfill_recurrences,
    refresh_echeances,
    scan_text,
    scan_document,
    process_pdf,
    # Budgets
    get_budgets,
    get_budget,
    add_budget,
    update_budget,
    delete_budget,
    get_budgets_status_api,
    get_budgets_summary_api,
    # Objectifs
    get_objectifs,
    add_objectif,
    update_objectif,
    delete_objectif,
    refresh_objectifs,
)

__all__ = [
    "initialize_backend",
    "add_transaction",
    "update_transaction",
    "delete_transaction",
    "get_structured_categories",
    "delete_attachment",
    "add_recurrence",
    "update_recurrence",
    "delete_recurrence",
    "backfill_recurrences",
    "refresh_echeances",
    "scan_text",
    "scan_document",
    "process_pdf",
    "get_budgets",
    "get_budget",
    "add_budget",
    "update_budget",
    "delete_budget",
    "get_budgets_status_api",
    "get_budgets_summary_api",
    # Objectifs
    "get_objectifs",
    "add_objectif",
    "update_objectif",
    "delete_objectif",
    "refresh_objectifs",
]
