"""
Settings Repository - Gestion de la configuration persistante en base de données.
"""
import logging
from typing import Optional
from shared.database import get_db_connection, close_connection

logger = logging.getLogger(__name__)

async def init_settings_table() -> bool:
    """Crée la table app_settings si elle n'existe pas."""
    conn = None
    try:
        conn = get_db_connection()
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TEXT
            )
        """)
        conn.commit()
        return True
    except Exception as e:
        logger.error(f"Error initializing app_settings: {e}")
        return False
    finally:
        close_connection(conn)

async def get_setting(key: str, default: Optional[str] = None) -> Optional[str]:
    """Récupère une valeur de configuration."""
    conn = None
    try:
        conn = get_db_connection()
        result = await conn.fetch_one("SELECT value FROM app_settings WHERE key = ?", (key,))
        return result["value"] if result else default
    except Exception as e:
        logger.error(f"Error getting setting {key}: {e}")
        return default
    finally:
        close_connection(conn)

async def set_setting(key: str, value: str) -> bool:
    """Enregistre ou met à jour une valeur de configuration."""
    from datetime import datetime
    conn = None
    try:
        conn = get_db_connection()
        await conn.execute(
            "INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?, ?, ?)",
            (key, value, datetime.now().isoformat())
        )
        conn.commit()
        return True
    except Exception as e:
        logger.error(f"Error setting {key}: {e}")
        return False
    finally:
        close_connection(conn)
