# Database Connection pour Mobile (Pyodide + Capacitor)
# vmobile = Version mobile uniquement - utiliser CapacitorConnection uniquement

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Flag pour détecter si on est dans un environnement de test
_IS_TEST = False


class Error(Exception):
    """Base class for database errors."""
    pass


class OperationalError(Error):
    """Error related to database operation."""
    pass


class IntegrityError(Error):
    """Error related to data integrity."""
    pass


def _get_js():
    """Récupère le module js si disponible (Pyodide), sinon retourne None."""
    try:
        import js

        return js
    except ImportError:
        return None


class CapacitorConnection:
    """
    Connexion SQLite pour mobile via Pyodide + Capacitor.
    Utilise le bridge JavaScript pour accéder à SQLite natif (@capacitor-community/sqlite).
    """

    def __init__(self):
        self._db = None
        self._js = _get_js()

    def cursor(self):
        """Retourne soi-même pour compatibilité avec l'API standard."""
        return self

    async def execute(self, query: str, params: tuple = ()) -> Any:
        """Exécute une requête SQL et retourne un cursor."""
        logger.debug(f"Awaiting _execute_async for: {query[:50]}")
        results = await self._execute_async(query, params)
        if results is None:
            logger.error(f"SQL Error: _execute_async returned None for query: {query}")
            results = []
        return _Cursor(results)

    async def _execute_async(self, query: str, params: tuple = ()) -> list[dict]:
        """Exécute une requête SQL de manière asynchrone via le bridge JS."""
        if self._js is None:
            # En test, retourner une liste vide
            if _IS_TEST:
                return []
            raise RuntimeError("CapacitorConnection requires Pyodide (js module)")

        try:
            logger.debug(f"SQL Execute (Bridge): {query[:50]} with {params}")
            if self._js is None:
                raise RuntimeError("self._js is None in CapacitorConnection")
            
            # Conversion explicite en liste pour JS
            sql_fn = self._js.executeSqlAsync
            if sql_fn is None:
                 raise RuntimeError("js.executeSqlAsync is not available")
            
            js_results = await sql_fn(query, list(params))

            # Conversion des résultats JS en Python
            if hasattr(js_results, "to_py"):
                results = js_results.to_py()
            else:
                results = js_results

            logger.debug(f"SQL Results: {len(results)} rows")
            return results

        except Exception as e:
            # Si le message d'erreur contient "already exists", on lève OperationalError
            # pour que schema.py puisse le catcher
            err_msg = str(e).lower()
            if "already exists" in err_msg or "duplicate column" in err_msg:
                raise OperationalError(str(e))
            
            logger.error(f"Erreur SQL ({query}): {e}")
            raise Error(str(e))

    def commit(self) -> None:
        """Valide les modifications."""
        pass

    def rollback(self) -> None:
        """Annule les modifications."""
        pass

    def close(self) -> None:
        """Ferme la connexion."""
        self._db = None

    async def fetch_all(self, query: str, params: tuple = ()) -> list[dict]:
        """Exécute un SELECT et retourne les résultats."""
        return await self._execute_async(query, params)

    async def fetch_one(self, query: str, params: tuple = ()) -> Optional[dict]:
        """Exécute un SELECT et retourne une seule ligne."""
        results = await self.fetch_all(query, params)
        return results[0] if results else None


class _Row(dict):
    """Un dict qui supporte l'accès par index pour compatibilité sqlite3."""
    def __getitem__(self, key):
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)

class _Cursor:
    """Cursor pour compatibilité avec le code existant."""

    def __init__(self, results: list[dict]):
        self.results = [_Row(r) for r in results]
        self._index = 0

    @property
    def description(self):
        if self.results:
            return [(k, None) for k in self.results[0].keys()]
        return []

    def fetchall(self) -> list[Any]:
        return self.results

    def fetchone(self) -> Optional[Any]:
        if self._index < len(self.results):
            result = self.results[self._index]
            self._index += 1
            return result
        return None

    def __iter__(self):
        return iter(self.results)


def get_connection() -> CapacitorConnection:
    """Factory qui retourne la connexion Capacitor."""
    return CapacitorConnection()


# Alias pour compatibilité
get_db_connection = get_connection
close_connection = lambda conn: conn.close() if conn else None


def set_test_mode(enabled: bool = True):
    """Active le mode test pour éviter les erreurs js non disponibles."""
    global _IS_TEST
    _IS_TEST = enabled


__all__ = [
    "Error",
    "OperationalError",
    "IntegrityError",
    "CapacitorConnection",
    "get_connection",
    "get_db_connection",
    "close_connection",
    "set_test_mode",
]
